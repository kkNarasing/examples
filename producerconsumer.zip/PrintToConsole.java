package com.my.ex.model;


public class PrintToConsole {
    private String  print;

    public PrintToConsole(String print) {
        this.print = print;

    }

    public String getPrint() {
        return print;
    }
}
