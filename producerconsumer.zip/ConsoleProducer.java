package com.my.ex.model;


import java.util.concurrent.ArrayBlockingQueue;
import java.util.stream.IntStream;

public class ConsoleProducer  implements Runnable {
    private ArrayBlockingQueue<PrintToConsole> queue;
    private Integer size;
    public ConsoleProducer(ArrayBlockingQueue<PrintToConsole> queue, int size) {
        this.queue = queue;
        this.size = size;

    }
    public void produce(PrintToConsole printToConsole) {
        try {
            queue.put(printToConsole);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        IntStream.range(0 , this.size).forEach(i -> {
            System.out.println(" producing for counter "+i);
            produce(new PrintToConsole("My NO " + i));
        });
    }
}
