package com.my.ex.model;

import java.util.concurrent.ArrayBlockingQueue;

public class RunMain {
    public static void main(String[] args) {

        int size = 10;
        ArrayBlockingQueue<PrintToConsole> queue = new ArrayBlockingQueue<>(size);
        Thread producer = new Thread( new ConsoleProducer(queue, 2*size)) ;
        Thread consumer = new Thread(new ConsoleConsumer(queue, size)) ;

        producer.start();
        consumer.start();

        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

//ganesh.gowtham@wellsfargo.com
    }
}
