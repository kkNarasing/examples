package com.my.ex.model;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.stream.IntStream;

public class ConsoleConsumer  implements Runnable{
    private ArrayBlockingQueue<PrintToConsole> queue;
    private Integer size;
    public ConsoleConsumer(ArrayBlockingQueue<PrintToConsole> queue, int size) {
        this.queue = queue;
        this.size =size;

    }

    public void consume(int counter)  {
        System.out.println("consuming for the counter "+counter);
        try {
            PrintToConsole printToConsole = queue.take();

            if(printToConsole != null) {
                System.out.println(printToConsole.getPrint());
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    @Override
    public void run() {
        IntStream.range(0, this.size).forEach(i -> consume(i));
    }
}
